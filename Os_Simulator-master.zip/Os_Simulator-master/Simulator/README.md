# Os_Simulator
Java Gui for Disk-Scheduling,Pagereplacement,Cpu-scheduling algorithms
